Installation Instructions for DD Download Files

The files contained in this diskette must be transferred to the "Software"
sub-directory located in the "Param" directory of Expressnet.  To transfer these files 
files, do the following:

1) At the "A" prompt type the following:

                A:\>copy *.* c:\xnet\param\software

                                OR

2)  at the "C" prompt type:

                C:\>copy a:\*.* xnet\param\software

NOTE: If you are an Expressnet3 user substitute "xnet3" for the "xnet" statements
      in the command  line.

Any questions or doubts, please contact Protel, Inc. at 941-644-5558 or write
us at:

                           Protel, Inc.
                           4150 Kidron Road
                           Lakeland, Florida  33811

Visit our WEBSITE at www.protelinc.com